#!/bin/ksh
# #####################################################################
# $Header: AWR.show_top5_wait_events.sh 30/03/2011 sduprat_es Exp $
#
# AWR.show_top5_wait_events.sh
#
# Copyright (c) 2011, Oracle Consulting (Spain).  All rights reserved.
#
#    NAME
#     AWR.show_top5_wait_events.sh
#
#    USAGE
#     AWR.show_top5_wait_events.sh <AWR SNAPSHOT> <INSTANCE_NUMBER>
#     AWR.show_top5_wait_events.sh -show => lists the available snapshots in the database !!!
#
#    DESCRIPTION
#     Collects instance wait events info from ASH Views.
#
#    NOTES
#       ### 1) Developped against Oracle RDBMS version 11.2 on Linux
#
#   VERSION  MODIFIED        (MM/DD/YY)
#    1.0.0    sduprat_es      30/03/11   - Creation and mastermind
#
# #####################################################################
#        Make sure to set the "Must set" variables below!
#
# Output is placed in a comma delimited file by default as follows:
#
#    /tmp/wl_app.dat seq, statistic name, value


function fn_show_snapshots
{
   ## Shows the available snapshots in the database !!!
   sqlplus $ora_access <<EOF
set lines 160 pages 500
col cmd format a70
col INSTANCE format a10
col DB_NAME format a10
select v.*,'$1 ' || v.bsnap || ' ' || v.INSTANCE_NUMBER || ' ' || v.DBID as cmd from (
select B.DBID, B.DB_NAME, B.INSTANCE_NAME as instance, A.INSTANCE_NUMBER, trunc(A.BEGIN_INTERVAL_TIME), min(A.SNAP_ID) as bsnap, max(A.snap_id) as esnap
from dba_hist_snapshot A, DBA_HIST_DATABASE_INSTANCE B
where A.dbid = B.dbid
and   A.INSTANCE_NUMBER = B.INSTANCE_NUMBER
group by B.DBID, B.DB_NAME, B.INSTANCE_NAME, A.INSTANCE_NUMBER, trunc(A.BEGIN_INTERVAL_TIME)
order by 1,2,3,4,5) v;  
exit
EOF

}


. ./perfil.sh


if [ $1 == "-show" ]
then
     fn_show_snapshots $0
     exit 0
fi

## Begin Snapshot and instance_number (RAC) values, passed on the command line.
bsnap=$1
inst_num=$2
dbid=$3

#
# Gather Instance metrics !!!
#

sqlplus -s $ora_access <<EOF
set heading on feedback off echo off
set linesize 500
col value format 9999999999999
col "Begin Snap=$bsnap - Instance=$inst_num" format a68
col xxx format a5

select V.* , (V.TotWaitFgSec*1000)/V.TotWaitsFg as AvgWaitMs 
from (
SELECT to_char(END.END_INTERVAL_TIME,'YYYYMMDDHH24MI') || '-' || to_char(BEG.END_INTERVAL_TIME,'YYYYMMDDHH24MI') || ',' ||
ENDSTAT.WAIT_CLASS || ',' || ENDSTAT.EVENT_NAME || ',' as "Begin Snap=$bsnap - Instance=$inst_num",
(NVL(ENDSTAT.TOTAL_WAITS,ENDSTAT.TOTAL_WAITS)-NVL(BEGSTAT.TOTAL_WAITS,BEGSTAT.TOTAL_WAITS)) as TotWaitsFg, 
(NVL(ENDSTAT.TIME_WAITED_MICRO,ENDSTAT.TIME_WAITED_MICRO)-NVL(BEGSTAT.TIME_WAITED_MICRO,BEGSTAT.TIME_WAITED_MICRO))/1000000 as TotWaitFgSec
FROM dba_hist_snapshot END,
     dba_hist_snapshot BEG,
     dba_hist_system_event ENDSTAT,
     dba_hist_system_event BEGSTAT
WHERE (BEG.snap_id = $bsnap)
AND   BEG.dbid = $dbid
AND   BEG.dbid = BEGSTAT.dbid
AND   BEG.dbid = ENDSTAT.dbid
AND   BEG.dbid = END.dbid
AND   END.snap_id = BEG.snap_id + 1
AND   END.snap_id = ENDSTAT.snap_id
AND   BEG.snap_id = BEGSTAT.snap_id
AND   BEGSTAT.WAIT_CLASS NOT IN ('Idle')
AND   BEGSTAT.WAIT_CLASS = ENDSTAT.WAIT_CLASS
AND   BEGSTAT.EVENT_NAME = ENDSTAT.EVENT_NAME
AND   END.instance_number = BEG.instance_number
AND   END.instance_number = ENDSTAT.instance_number
AND   END.instance_number = BEGSTAT.instance_number
AND   END.instance_number = $inst_num
order by 3 desc
) V where rownum < 6
/
exit
EOF

# Remove work files
#
