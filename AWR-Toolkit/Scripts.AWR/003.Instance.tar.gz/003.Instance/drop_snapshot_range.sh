echo "exec dbms_workload_repository.DROP_SNAPSHOT_RANGE(47942,47946,154714002)" | sqlplus -s / as sysdba
echo "exec dbms_workload_repository.DROP_SNAPSHOT_RANGE(47947,47994,154714002)" | sqlplus -s / as sysdba
echo "exec dbms_workload_repository.DROP_SNAPSHOT_RANGE(47995,48036,154714002)" | sqlplus -s / as sysdba
echo "exec dbms_workload_repository.DROP_SNAPSHOT_RANGE(48037,48084,154714002)" | sqlplus -s / as sysdba
echo "exec dbms_workload_repository.DROP_SNAPSHOT_RANGE(48085,48107,154714002)" | sqlplus -s / as sysdba
