/**
 * 
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;

/**
 * @author operard
 *
 */
public class StatementSample {

	private final String user;
	private final String password;
	private final String url;
	
	private static final String sql = "select * from AGREEMENTS";

	/**
* Creates an StatementDemo instance with the given details.
* @param user
* @param pwd
* @param url
*/
	private StatementSample(String user, String pwd, String url) {
		this.user = user;
		this.password = pwd;
		this.url = url;
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StatementSample tst = new StatementSample("rap002", "rap002", "jdbc:oracle:thin:@rapdb_low");
		tst.executeQuery(sql);
		System.exit(0);
	}
	
	/**
	 * Creates an OracleConnection instance and return it.
	 * @return oracleConnection
	 * @throws SQLException
	 */
	private OracleConnection getConnection() throws SQLException {
		OracleDataSource ods = new OracleDataSource();
		ods.setUser(user);
		ods.setPassword(password);
		ods.setURL(url);
		return (OracleConnection)ods.getConnection();
	}

/**
 * Selects all the rows from the employee table.
 * @param connection
 */
	private void executeQuery (String sql) {
		OracleConnection connection = null;
		try{
			connection = getConnection();
		    try(Statement stmt = connection.createStatement()) {
			      ResultSet rs = stmt.executeQuery(sql);
			      while(rs.next()) {
			    	  // Get Data
			    	  /*
			            System.out.println("Column Type\t\t Column Name");

			            ResultSetMetaData rsmd = rs.getMetaData();
		                for (int i = 1; i <= rsmd.getColumnCount(); i++) {
		                    System.out.println(rsmd.getColumnTypeName(i)+"\t\t\t"+rsmd.getColumnName(i));
		                }
		                */
			    	  ResultSetMetaData rsmd = rs.getMetaData();
			          for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			              if (i > 1) {
			            	  System.out.print(",");
			              }

			              int type = rsmd.getColumnType(i);
			              if (type == Types.VARCHAR || type == Types.CHAR) {
			            	  System.out.print(rs.getString(i));
			              } else {
			            	  System.out.print(rs.getString(i));
			              }
			          }

			          System.out.println();			    	  
			      }
			    }
			    catch(SQLException sqle) {
			    	sqle.printStackTrace();
			    }
			
		}catch(SQLException sqle2){
			sqle2.printStackTrace();
		}finally{
			if (connection!=null)
				try {
					connection.close();
					connection = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	

}

