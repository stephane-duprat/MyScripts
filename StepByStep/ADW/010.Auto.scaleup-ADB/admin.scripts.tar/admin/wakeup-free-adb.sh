#!/bin/sh

ORACLE_HOME=/home/opc/instantclient_18_3
LD_LIBRARY_PATH=/home/opc/instantclient_18_3
PATH=$ORACLE_HOME:$PATH
TNS_ADMIN=$ORACLE_HOME/network/admin

export ORACLE_HOME LD_LIBRARY_PATH PATH

echo "start /home/opc/admin/monitor.adw.sql" | sqlplus -s admin/AaZZ0r_cle#1@myatpdb_tp
echo "start /home/opc/admin/monitor.adw.sql" | sqlplus -s admin/AaZZ0r_cle#1@sduadwdb_low

exit 0
